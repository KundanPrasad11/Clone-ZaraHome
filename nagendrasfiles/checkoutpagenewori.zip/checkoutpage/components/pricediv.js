function pricediv () {

    return ` 
    <h3 class="highlight" >2 ITEMS</h3>
    <hr>
  
    <div > <span>Total items: including tax</span> <span class="prices">45€</span></div>
    <div><span>Delivery charges:</span> <span class="prices">45€</span></div>
    <div><span>Import costs:</span> <span class="prices">45€</span></div>
    <div id="totaldiv"><span>TOTAL:</span> <span class="prices">45€</span></div>
    <p>DO YOU HAVE A PROMOTIONAL CODE? Enter it when you reach the payment page</p>

    <button class="newaddbtn " id="addcontbtn">CONTINUE</button>
   </div>
   `;
}

export {pricediv};